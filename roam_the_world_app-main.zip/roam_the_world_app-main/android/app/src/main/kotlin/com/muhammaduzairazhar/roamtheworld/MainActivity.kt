package com.muhammaduzairazhar.roamtheworld

import io.flutter.embedding.android.FlutterFragmentActivity

class MainActivity : FlutterFragmentActivity() {
    // No need to override onCreate just to set the theme
    // The theme should be set in AndroidManifest.xml
}