import 'dart:ui';

class AppConstant{



  static String publishKey='pk_test_51R58yuKG1PBkJ7Ea5Q23vUQBl5fl9HAk9UJLBaF60wQGT7CwQ5uqjE3J3x8GMG3g7rDS63uG41wGK8VqMFh5Lgtl00oKSUSm1i';
  static String secretKey='sk_test_51R58yuKG1PBkJ7EaahfVKg9v3c5cuKcO3npUSgRAutvqD3Pj34JzEvrHoz0p5dPT1FAefZoniDFFCgfDHMn4yR7R00M07MfzFg';

}