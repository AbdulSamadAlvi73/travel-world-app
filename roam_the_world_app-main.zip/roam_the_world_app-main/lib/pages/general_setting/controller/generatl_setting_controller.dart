import 'package:get/get.dart';

class GeneratlSettingController extends GetxController {
  bool allowOtherUsersToMessage = false;
}
