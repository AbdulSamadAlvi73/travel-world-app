import 'package:get/get.dart';

class ChangePasswordController extends GetxController {
  bool isOldPasswordVisible = false;
  bool isNewPasswordVisible = false;
  bool isConfirmNewPasswordVisible = false;
}
