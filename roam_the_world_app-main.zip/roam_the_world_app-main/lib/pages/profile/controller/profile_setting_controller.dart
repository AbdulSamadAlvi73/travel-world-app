import 'package:get/get.dart';

class ProfileSettingController extends GetxController {}
